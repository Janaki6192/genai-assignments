# UI Development Prompt — ReviewBot (Pull Request Reviewer)

**Role:** You are a senior front-end engineer and product designer. Build a production-quality, single-page web UI for an AI-powered GitHub code reviewer.

## 1. Goal
Build "ReviewBot — Pull Request Reviewer", a web page where a developer pastes a GitHub file URL, clicks **Review Code**, and gets an AI review back from an n8n workflow. The review is shown as a formatted report.

## 2. Tech constraints
- Plain **HTML + CSS + vanilla JavaScript** in one file (`index.html`). No build step and no framework.
- Allowed CDN libraries: `marked` (Markdown → HTML) and `DOMPurify` (sanitising the HTML).
- Must run from any static server (e.g. `python -m http.server 8765`).
- All settings sit in one `CONFIG` object at the top of the script: the webhook URL, the sample file URL and the request timeout.

## 3. Backend contract (n8n)
- `POST {CONFIG.WEBHOOK_URL}` with JSON body `{ "url": "<raw GitHub file URL>" }`.
- The response is either JSON `{ "review": "<markdown>" }` or plain-text Markdown. Handle both.
- The review Markdown contains a parameter score table (5 parameters, each out of 20), an overall score out of 100, a list of improvement areas and a summary.

## 4. Layout & components
1. **Header:** the brand mark (sparkle icon in a rounded tile), the wordmark "ReviewBot." a **Dark mode** toggle and a **Service status** pill (idle / reviewing / last review succeeded / last review failed).
2. **Hero:** the eyebrow "AI-Powered CODE REVIEW"; the H1 "ReviewBot — **Pull Request Reviewer**" with the second half in the accent colour; the sub-copy "Every line of code, reviewed before it ships…"; a decorative orbit illustration with a sparkle tile.
3. **Two-column workspace** (stacks to one column under 960px):
   - **Left column**
     - *Start a code review* card: a GitHub file URL input (monospace), a primary **Review Code** button, a **Try a sample** chip and the helper text "Paste a raw GitHub URL or a normal GitHub file link."
     - *Consistent Quality → Review Guidelines*: a checklist of five focus areas (Code Readability, Code Efficiency, Error Handling, Maintainability, Best Practices & Standards).
   - **Right column:** *Your code, in focus → Review results*
     - A status chip ("Ready when you are" / "Reviewing…" / "Review complete" / "Review failed").
     - A results card with the eyebrow "AI-Powered CODE REVIEW", the file name, and **Copy review** and **Download report** (.md) buttons.
     - The rendered Markdown review with styled tables, inline code and headings.
     - An empty state before the first review and a skeleton loader while reviewing.
4. **Footer** with a short credit line.

## 5. Behaviour
- Accept both `github.com/<owner>/<repo>/blob/<branch>/<path>` and `raw.githubusercontent.com/...`. Convert blob links to raw links before sending.
- Validate the input: it must not be empty and must be a GitHub link. Show inline errors.
- Disable the button and show a spinner while a request is in flight. Abort after `CONFIG.TIMEOUT_MS`.
- Show friendly error messages for network, CORS, timeout and non-200 responses.
- Pressing Enter in the input submits the review.
- Store the dark-mode choice in localStorage (wrapped in try/catch) and respect `prefers-color-scheme`.

## 6. Visual design
- Clean enterprise look: soft Midnight Indigo background with a subtle radial gradient, white cards with 20px radius, 1px borders and soft shadows.
- Primary colour: deep charcoal-to-vibrant lime (`#20252e → #A3E635`). Accent colour: `#64748B`.
- Font: **Inter** (Google Fonts) for text and **JetBrains Mono** for code.
- Small uppercase, letter-spaced eyebrows above section titles.
- Accessible: visible focus rings, `aria-live` on results, labelled inputs, AA contrast in both themes.

## 7. Deliverable
One complete `index.html` file with no placeholders except `CONFIG`.
